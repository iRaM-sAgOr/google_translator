import pandas as pd
import sys


csv1 = 'temp/clean_tweet_japanese.csv'
csv2 = 'temp/clean_tweet_japanese2.csv'
csv_t = 'testing_data.csv'
df_csv1 = pd.read_csv(csv1, index_col=[0], encoding='utf8')
# df_csv1 = df_csv1.drop(columns=['text'])
df_csv1.dropna(inplace=True)
df_csv1.reset_index(drop=True, inplace=True)

# df_cs = pd.read_csv(csv_t, index_col=[0], encoding='utf8')
# print (df_cs.iloc[:, 2:3].values)
df_csv2 = pd.read_csv(csv2, index_col=[0])
# df_csv2 = df_csv2.drop(columns=['text'])
df_csv2.dropna(inplace=True)
df_csv2.reset_index(drop=True, inplace=True)

merged = df_csv1.merge(df_csv2)
merged.to_csv("output.csv",index=False)


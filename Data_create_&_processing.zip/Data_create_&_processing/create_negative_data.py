#!/usr/bin/env python
# -*- coding: utf-8 -*-

from mtranslate import translate
import pandas as pd

japanese_text = []


def main(to_translate):
    text = translate(to_translate, 'ja')
    japanese_text.append(text)
    print(text)


if __name__ == '__main__':
    csv = 'data/clean_tweet.csv'
    my_df = pd.read_csv(csv, index_col=[0], encoding='iso-8859-1')
    my_df.dropna(inplace=True)
    my_df.reset_index(drop=True, inplace=True)
    text = my_df.text
    sentiment = my_df.target
    j = 2701
    for i in range(2701, len(text)):
        print("\033[1;33;47m")
        main(text[i])
        if i % 100 == 0:
            print("\033[1;31;40m " + str(i) + "\033[1;32;40m Data Have Been translated from \033[1;37;40m " + str(
                len(text)) + " data")
            clear_text_japanese = pd.DataFrame()
            clear_text_japanese['target'] = my_df.target[j:i]
            clear_text_japanese['text'] = my_df.text[j:i]
            clear_text_japanese['japanese_lan'] = japanese_text
            clear_text_japanese.to_csv('clean_tweet_japanese2.csv', encoding='utf-8')
        j += 1

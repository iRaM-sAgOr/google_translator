import pandas as pd
from mtranslate import translate

japanese_text_list = []
english_text_list = []


def main(to_translate):
    text = translate(to_translate, 'ja')
    japanese_text_list.append(text)
    english_text_list.append(to_translate)
    print(text)


csv1 = 'data/clean_tweet.csv'
csv2 = 'clean_tweet_japanese2.csv'
my_df = pd.read_csv(csv1, index_col=[0], encoding='utf8')
my_df.dropna(inplace=True)
my_df.reset_index(drop=True, inplace=True)
text_list = []
target_list = []
count = 0
my_df = my_df.sort_values('target', ascending=False)
for i, j in my_df.iterrows():
    if j["target"] == 1:
        text_list.append(j['text'])
        target_list.append(1)
        print("Processing..................")
        count += 1
    if count == 50000:
        break
j = 0
for i in text_list:
    if j > 24500:
        print("\033[1;33;47m")
        main(i)
        if j % 10 == 0:
            print(j, len(target_list[24500:j + 1]), len(english_text_list), len(japanese_text_list))
            print("\033[1;31;40m " + str(j) + "\033[1;32;40m Data Have Been translated from \033[1;37;40m " + str(
                len(text_list)) + " data")
            clear_text_japanese = pd.DataFrame()
            clear_text_japanese['target'] = target_list[24500:j]
            clear_text_japanese['text'] = english_text_list
            clear_text_japanese['japanese_lan'] = japanese_text_list
            clear_text_japanese.to_csv('testing_data.csv', encoding='utf8')
    j += 1

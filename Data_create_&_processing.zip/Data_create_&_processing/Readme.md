*********instruction to understand the code*************
1. In this module we have automated the Google translator using html parser. 
2. Here in translator folder we have all our translator programs. And in create positive data and create negative data python file we have the code of translating the positive and negative data. 
3. We have our main english preprocessed dataset "clear_tweet.csv". And using this dataset and translator code we generate some csv with different sentiment in data folder.
4. And in data folder we have a script to combine the csv and generate another csv named "combined_csv"

